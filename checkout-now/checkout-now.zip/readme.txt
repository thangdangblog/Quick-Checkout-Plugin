=== Flatsome Quick Checkout ===
Contributors: Thang Dang
Tags: flatsome, quick checkout
Requires at least: 4.7.0
Tested up to: 5.2
Requires PHP: 5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Customize WordPress with powerful, professional and intuitive fields.

== Description ==

Use the Flatsome Quick Checkout to checkout when customers are at the product page, homepage or shop.


= Features =
* Simple & Intuitive


= Links =
* [Website](https://thangdangblog.com/flatsome-quick-checkout-plugin-tao-nut-thanh-toan-nhanh-cho-flatsome/)
* [Documentation](https://thangdangblog.com/flatsome-quick-checkout-plugin-tao-nut-thanh-toan-nhanh-cho-flatsome/)
* [Support](https://thangdangblog.com/flatsome-quick-checkout-plugin-tao-nut-thanh-toan-nhanh-cho-flatsome/)

== Installation ==

From your WordPress dashboard

1. **Visit** Plugins > Add New
2. **Search** for "Flatsome Quick Checkout"
3. **Activate** Flatsome Quick Checkout from your Plugins page


== Frequently Asked Questions ==



== Screenshots ==

1. Simple & Intuitive

== Changelog ==

